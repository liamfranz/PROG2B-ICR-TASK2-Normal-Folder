﻿using System;
using System.Threading;

namespace ThreadBasicsDemo
{
    class Program
    {
        
        static void PrintMessage()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"[Thread] I am running in a thread - {i + 1}");
                Thread.Sleep(500); 
            }
        }

        static void Main(string[] args)
        {
            
            Thread thread = new Thread(PrintMessage);

            
            thread.Start();

            
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"[Main] I am running in the main method - {i + 1}");
                Thread.Sleep(500);
            }

            
            thread.Join();

            Console.WriteLine("Both threads have finished running.");
        }
    }
}
