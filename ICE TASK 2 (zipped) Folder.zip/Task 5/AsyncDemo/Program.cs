﻿using System;
using System.Threading.Tasks;

namespace AsyncDemo
{
    class Program
    {
        static async Task DoWorkAsync()
        {
            await Task.Delay(2000);
            Console.WriteLine("Async work completed");
        }

        static async Task Main(string[] args)
        {
            var task = DoWorkAsync();
            Console.WriteLine("Main method continues running...");
            await task;
        }
    }
}
