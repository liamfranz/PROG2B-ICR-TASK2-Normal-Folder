﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncDelegateDemo
{
    class Program
    {
        delegate void WorkDelegate();

        static void DoWork()
        {
            Console.WriteLine($"Work started at {DateTime.Now:HH:mm:ss.fff}");
            Thread.Sleep(2000);
            Console.WriteLine($"Work finished at {DateTime.Now:HH:mm:ss.fff}");
        }

        static async Task Main(string[] args)
        {
            WorkDelegate work = new WorkDelegate(DoWork);

            Console.WriteLine("Starting async delegate...");

            Task task = Task.Run(() => work());

            Console.WriteLine("Main thread is still running...");

            await task;

            Console.WriteLine("Async delegate has completed.");
        }
    }
}
