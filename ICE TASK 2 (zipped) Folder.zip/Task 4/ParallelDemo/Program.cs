﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Parallel.For loop:");
            Parallel.For(0, 10, i =>
            {
                Console.WriteLine($"Task {i} is running");
                Thread.Sleep(200);
            });

            Console.WriteLine("\nRegular for loop:");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Task {i} is running");
                Thread.Sleep(200);
            }
        }
    }
}
