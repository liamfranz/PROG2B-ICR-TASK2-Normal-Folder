﻿using System;
using System.Threading;

namespace RaceConditionDemo
{
    class Program
    {
        static int counter = 0;

        static void Increment()
        {
            for (int i = 0; i < 1000; i++)
            {
                counter++;
            }
        }

        static void Main(string[] args)
        {
            Thread[] threads = new Thread[5];

            for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(Increment);
                threads[i].Start();
            }

            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].Join();
            }

            Console.WriteLine($"Final counter value: {counter}");
        }
    }
}
